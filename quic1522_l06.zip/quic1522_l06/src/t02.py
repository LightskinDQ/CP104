"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import sum_odd
# Constants

num = int(input("Please enter a number: "))
total1 = sum_odd(num)
print(total1)

