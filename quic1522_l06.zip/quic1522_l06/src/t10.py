"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import treadmill

# Constants
start = int(input("Enter the start time in minutes: "))
end = int(input("Enter the end time in minutes: "))
inc = int(input("Enter the increment time in minutes: "))
burnt_per_minute = float(input("Enter the calories burnt per minute: "))
print()
treadmill(burnt_per_minute, start, end, inc)
