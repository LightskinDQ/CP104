"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import draw_rectangle


height = int(input("Please enter a height: "))
width = int(input("Please enter a width: "))
char = str(input("Please enter a character: "))
draw_rectangle(height, width, char)

        
            