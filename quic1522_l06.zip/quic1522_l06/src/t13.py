"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import lumber

# Constants

    

b_min = int(input("Enter the minimum value of the base: "))
b_max = int(input("Enter the maximum value of the base: "))
b_inc = int(input("Enter the increment value for the base: "))
h_min = int(input("Enter the minimum value of the height: "))
h_max = int(input("Enter the maximum value of the height: "))
h_inc = int(input("Enter the increment value for the height: "))
lumber(b_min, b_max, b_inc, h_min, h_max, h_inc)      


        
        
        
        
        
        
        
        
        
        
        
        
        
