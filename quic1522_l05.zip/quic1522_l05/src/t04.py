"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports

from functions import closest

target = float(input("Please enter a target number: "))
v1 = float(input("Please enter a number: "))
v2 = float(input("Please enter another number: "))

result = closest(target, v1, v2)
print(result)

#error regarding if else only algorithm