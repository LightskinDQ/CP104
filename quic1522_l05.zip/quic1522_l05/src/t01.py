"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports
from functions import magic_date

year = int(input("Please input the year: "))
month = int(input("Please input the month: "))
day = int(input("Please input the day: "))

magic = magic_date(day, month, year)
print(magic)


