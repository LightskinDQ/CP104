"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports
from functions import pay_raise

status = input("Please enter your status as an employee in either F or P: ")
status = status.upper()
years = int(input("Please enter the number of years you worked at the company: "))
salary = float(input("Please enter your salary: $"))

salary = pay_raise(status, years, salary)
print(f"{salary:.2f}")

