"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports

from functions import ticket

price = ticket() 
print()
print(f"{price:.2f}")

#Dosnt use uppercase constants for ticket ages
