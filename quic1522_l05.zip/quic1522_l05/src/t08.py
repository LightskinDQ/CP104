"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports

from functions import roman_numeral
n = int(input("Please input a number: "))
numeral = roman_numeral(n)
print(numeral)
