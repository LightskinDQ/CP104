"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import day_of_week

day_number = int(input("Please input a number: "))
day = day_of_week(day_number)
print(f"{day}")

    