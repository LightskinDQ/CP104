"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import pollution_level

aqi = int(input("Please input the Air Quality index as a number: "))
level = pollution_level(aqi)
print(f"{level}")
