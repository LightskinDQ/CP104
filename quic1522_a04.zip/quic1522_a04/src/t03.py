"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import product_largest
v1 = float(input("Please input a number: "))
v2 = float(input("Please input a number: "))
v3 = float(input("Please input a number: "))
product = product_largest(v1, v2, v3)
print(f"{product:.2f}")