"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""
# Imports
from functions import rgb_mix
rgb1 = str.lower(input("Please enter a colour from the following; red, green, or blue: "))
rgb2 = str.lower(input("Please enter a colour from the following; red, green, or blue: "))
colour = rgb_mix(rgb1, rgb2)
print(f"{colour}")