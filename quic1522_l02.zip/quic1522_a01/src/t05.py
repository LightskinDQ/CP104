"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

Principal_amount = float(input("Principal: $"))
Rate_of_Interest = float(input("Interest (decimal): "))
Years = int(input("Number of years: "))
Interest_compounded = int(input("Number of times interest compounded per year: "))
Balance = Principal_amount*(1+(Rate_of_Interest/Interest_compounded))**(Interest_compounded*Years)
print(f"Balance: ${Balance:f}")