"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

Pizza_Cost = float(input("Cost of 1 pizza slice: $"))
Number_Slices = int(input("Number of pizza slices: "))
Total = Pizza_Cost*Number_Slices
print(f"Total cost of {Number_Slices:d} pizza slices: $ {Total:.2f}")
