"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports
C = 0.0254
Length = int(input("Length in inches: "))
Meters = Length*C
print(f"Length in m: {Meters:f}")