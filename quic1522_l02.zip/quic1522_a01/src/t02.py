"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

Fav_food = str(input("Enter your favourite food: "))
Fav_show = str(input("Enter your favourite TV show: "))
print(f"I like to eat {Fav_food:s} while watching {Fav_show:s}")