"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-17"
-------------------------------------------------------
"""
# Imports
from functions import date_extract

date_number = int(input("Enter a date in the format MMDDYYYY: "))
reformatted_date= date_extract(date_number)
year, month, day = reformatted_date
print(f"The reformatted date: {year}/{month}/{day}")