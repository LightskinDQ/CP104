"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

Number = float(input("Enter a number: "))
Percent = float(input("Enter a percent: "))
#Enter Variables
total = Number*(Percent/100)
#Gets total
print(f"A {Percent} percent discount on {Number} is {total:.1f}")
