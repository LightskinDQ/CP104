"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

integer = 654321
decimal = 654.32
phrase = "Hello World"

print(f"{integer:d}")
print(f"{integer:f}")
#print(f"{integer:s}")

#print(f"{decimal:d}")
print(f"{decimal:f}")
#print(f"{decimal:s}")

#print(f"{phrase:f}")
#print(f"{phrase:d}")
print(f"{phrase:s}")

