"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports 

Sweatband_Cost = float(input("Enter Sweatband Cost: $"))
Pants_Cost = float(input("Enter Pants Cost: $"))
Jacket_Cost = float(input("Enter Jacket Cost: $"))
#Enter prices of clothes
Total = Sweatband_Cost + Pants_Cost + Jacket_Cost
#Variable to hold total of all clothes
print("")
print("Clothes               Cost")
print(f"Sweatband            $ {Sweatband_Cost:>6.2f}")
print(f"Pants                $ {Pants_Cost:>6.2f}")
print(f"Jacket               $ {Jacket_Cost:>6.2f}")               
print(f"Total                $ {Total:>6.2f}")




