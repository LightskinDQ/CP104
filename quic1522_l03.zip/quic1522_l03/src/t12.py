"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

first = 100
second = 34
third = 933
total = first + second + third
#Adds total of all variables

print(f"""
Values
First:  {first:_>6d}
Second: {second:_>6d}
Third:  {third:_>6d}
Total:  {total:_>6d}
""")
