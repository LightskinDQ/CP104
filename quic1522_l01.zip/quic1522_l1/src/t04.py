"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-09-14"
-------------------------------------------------------
"""
# Imports

name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)

