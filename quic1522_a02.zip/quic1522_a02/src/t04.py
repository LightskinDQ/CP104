"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""
# Imports

cake = int(input("Number of pieces of cake: "))
people = int(input("Number of party-goers: "))
slices_per_person = cake // people
remainder = cake % people
print(f"""
Each party-goer receives {slices_per_person} pieces of cake
Pieces of cake that won’t be distributed: {remainder}""")