"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""
# Imports
length = float(input("Foundation length (m): "))
width = float(input("Foundation width (m): "))
height = float(input("Foundation height (m): "))
Wall_height = float(input("Wall height (m): "))
Cost_concrete = float(input("Cost of concrete ($/m^3): "))
Cost_brick = float(input("Cost of bricks ($/m^2): "))

Foundation = length*width*height
Concrete_total = Cost_concrete*Foundation
Bricks = ((width*Wall_height)*2)+((length*Wall_height)*2)
Brick_total = Bricks*Cost_brick
total = Brick_total+Concrete_total
print(f"""
Concrete needed for foundation (m^3): {Foundation:,.2f}
Cost of concrete: ${Concrete_total:,.2f}
Bricks needed for walls (m^2): {Bricks:,.2f}
Cost of bricks: ${Brick_total:,.2f}
Total cost: ${total:,.2f}
""")