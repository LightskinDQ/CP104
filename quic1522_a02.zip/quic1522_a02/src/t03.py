"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""
# Imports

date = int(input("Enter a date in the format DDMMYYYY: "))

day = date // 1000000
month = (date // 10000) - (day*100)
year = date - ((date // 10000)*10000)
print(f"""
The Reformatted date: {year}/{month}/{day}""")




