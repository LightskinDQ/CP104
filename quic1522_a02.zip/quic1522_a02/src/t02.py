"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""
# Imports

number = int(input("Enter a positive 2 digit number: "))
num1 = number
mod = num1%10
div = num1//10
total = mod*div
print(f"""
The product of the digits of {number} is {total}""")