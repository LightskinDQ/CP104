"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Dillon Quick
ID: 169031522
Email: quic1522@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""
# Imports

Total_sales = int(input("Enter the total sales: $"))
ANNUAL_TAX = 18.50
Tax = Total_sales*(ANNUAL_TAX/100)
print(f"""
Projected Tax Report
--------------------------
Total sales:    $ {Total_sales:.2f}
Annual tax:     % {ANNUAL_TAX:.2f}
--------------------------
Tax:            $  {Tax:.2f}
""")
